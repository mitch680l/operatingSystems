var searchData=
[
  ['update_5fback_5fexample_120',['update_back_Example',['../group__DEQUE.html#ga0705ac52e0952213b9f1ce7f80bf977e',1,'deque.h']]],
  ['update_5ffront_5fexample_121',['update_front_Example',['../group__DEQUE.html#ga2f5457e6575eb38d59b7504770ca247e',1,'deque.h']]]
];
