var searchData=
[
  ['redirect_243',['Redirect',['../parsing__interface_8h.html#a4450bbf0a834296444c4c2a2dfeb0689',1,'parsing_interface.h']]]
];
