var searchData=
[
  ['apply_5fexample_145',['apply_Example',['../group__DEQUE.html#ga582c40f070af171e4c98455d7d6fd305',1,'deque.h']]],
  ['as_5farray_5fexample_146',['as_array_Example',['../group__DEQUE.html#ga0214e3a819ca3e1ec44d2f60d7c28f7b',1,'deque.h']]]
];
